# ROHO exploratory pilot

Shared-template synthetic pilot; not main-study evidence. Mock is software validation only.

Backend: huggingface-local

| Arm | Success | Lost / baseline solved | Mean tokens | Search tokens |
|---|---:|---:|---:|---:|
| A | 60.0% | 0 / 3 | 602.6 | 0 |
| C | 60.0% | 0 / 3 | 602.6 | 918 |
| D | 60.0% | 0 / 3 | 602.6 | 918 |
| E | 60.0% | 0 / 3 | 602.6 | 918 |

Search totals exclude the shared H0 evaluation, which is separately recorded in state.json and model_calls.jsonl. These one-seed descriptive pilot results have no inferential confidence intervals.
